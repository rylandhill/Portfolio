import statistics
filObject=open("input.txt")
fileString=filObject.read()
fileList=fileString.splitlines()
total=0
total2=0
answ2=[]
currlist=[]

def split(word):
  return [char for char in word]

for item in fileList:
  indiv=split(item)
  currlist=[]
  stopper=0
  counter=0
  total2=0
  for characters in indiv:
    if stopper==0:
      if characters==">":
        if currlist[-1]!="<":
          total+=25137
          stopper=1
        elif currlist[-1]=="<":
          currlist.pop(-1)
      elif characters=="}":
        if currlist[-1]!="{":
          total+=1197
          stopper=1
        elif currlist[-1]=="{":
          currlist.pop(-1)
      elif characters=="]":
        if currlist[-1]!="[":
          total+=57
          stopper=1
        elif currlist[-1]=="[":
          currlist.pop(-1)
      elif characters==")":
        if currlist[-1]!="(":
          total+=3
          stopper=1
        elif currlist[-1]=="(":
          currlist.pop(-1)
      else:
        currlist.append(characters)
  if stopper==0:
    currlist.reverse()
    for remains in currlist:
      total2=total2*5
      if remains=="<":
        total2+=4
      elif remains=="{":
        total2+=3
      elif remains=="[":
        total2+=2
      elif remains=="(":
        total2+=1
    answ2.append(total2)
    answ2.sort()

med=statistics.median(answ2)
print(med)
print(total)