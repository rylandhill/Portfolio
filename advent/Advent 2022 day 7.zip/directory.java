import java.util.*;
public class directory{
    int sum;
    String name;
    directory parentDirectory;
    ArrayList<directory> subDirectories;
    public directory(String name){
        this.name = name;
        sum=0;
        subDirectories = new ArrayList<directory>();
        parentDirectory = null;
    }
    public String getName(){
        return this.name;
    }
    public void addSum(int num){
        sum+=num;
    }
    public directory getParent(){
        return parentDirectory;
    }
    public void addDirectory(directory xx){
        subDirectories.add(xx);
    }
    public void setParent(directory parent){
        this.parentDirectory = parent;
    }
    public int getSum(){
      int total = this.sum;
      for (int index=0;index<subDirectories.size();index++){
        total += subDirectories.get(index).getSum();
      }
      return total;
    }
    public ArrayList<directory> getSubs(){
      return subDirectories;
    }
}