import java.util.*;
import java.io.*;

public class Main {
    
    public static void main(String[] args) {
        ArrayList<directory> allDirectories = new ArrayList<directory>();
        ArrayList<String> instructions = new ArrayList<String>();
        directory current = new directory("/");
        allDirectories.add(current);
        File file = new File("input.txt");
        try{
        Scanner sc = new Scanner(file);
        while (sc.hasNextLine())
            instructions.add(sc.nextLine());
        }
        catch(FileNotFoundException e){}
        for (int index=0;index<instructions.size();index++){
            String firstChar = String.valueOf(instructions.get(index).charAt(0));
            if(firstChar.equals("$")){
                String thirdChar = String.valueOf(instructions.get(index).charAt(2));
                if (thirdChar.equals("c")){
                  String dirName = String.valueOf(instructions.get(index)).substring(5);
                    if(dirName.equals("..")){
                      current = current.getParent();
                    }else{
                    ArrayList<directory> currentSubs = current.getSubs();
                    for (int i=0;i<currentSubs.size();i++){
                        if (currentSubs.get(i).getName().equals(dirName)){
                            current = currentSubs.get(i);
                        }
                    }
                    }
                }else{
                }
            }else if(firstChar.equals("d")){
                String dirName = String.valueOf(instructions.get(index)).substring(4);
                directory newDir = new directory(dirName);
                newDir.setParent(current);
                current.addDirectory(newDir);
                allDirectories.add(newDir);
            }else{
              String currentLine = instructions.get(index);
              String nums = "";
              for (int j=0;j<currentLine.length();j++){
                if(Character.isDigit(currentLine.charAt(j))){
                  nums += String.valueOf(currentLine.charAt(j));
                }
              }
              int num = Integer.parseInt(nums);
              current.addSum(num);
            }
        }
      int totalVal = 0;
      System.out.println(allDirectories.get(0).getSum());
      int currentFree = 27441688;
      int needed = 2558312;
      for (int finIndex=0;finIndex<allDirectories.size();finIndex++){
        directory currDir = allDirectories.get(finIndex);
        if (currDir.getSum()>=needed){
          System.out.println(currDir.getSum());
        }
      }
      
    }
}