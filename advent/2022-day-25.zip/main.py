import math
fileObject = open("input.txt")
fileString = fileObject.read()
fileList = fileString.splitlines()

def checkPotential(bits):
  totalVal = (math.pow(5,bits)-1)/2
  return totalVal

def getSNAFUlen(decimal):
  for bit in range(1,999999999999999999):
    if (decimal>checkPotential(bit)):
      continue
    else:
      return bit

def DecimaltoSNAFU(decimal):
  snafuLen = getSNAFUlen(decimal)
  currentVal = 0
  snafuList = []
  while (currentVal!=decimal):
    print(snafuList)
    potential = checkPotential(snafuLen-len(snafuList)-1)
    if (potential+currentVal<decimal):
      if (potential+currentVal+math.pow(5,snafuLen-len(snafuList)-1)>=decimal):
        currentVal+=math.pow(5,snafuLen-len(snafuList)-1)
        snafuList.append("1")
      else:
        currentVal+=math.pow(5,snafuLen-len(snafuList)-1)*2
        snafuList.append("2")
    elif (currentVal-potential>decimal):
      if (currentVal-math.pow(5,snafuLen-len(snafuList)-1)+potential>=decimal in and currentVal-math.pow(5,snafuLen-len(snafuList)-1)-potential<=decimal):
        currentVal-=math.pow(5,snafuLen-len(snafuList)-1)
        snafuList.append("-")
      else:
        currentVal-=math.pow(5,snafuLen-len(snafuList)-1)*2
        snafuList.append("=")
    else:
      snafuList.append("0")
  while (snafuLen>len(snafuList)):
    snafuList.append("0")
  return "".join(snafuList)

def SNAFUtoDecimal(snafu):
  total = 0
  snafuLen = len(snafu)
  for index in range(1,snafuLen+1):
    index = index*-1
    char = snafu[index]
    if char == "=":
      total -= 2*(math.pow(5,abs(index)-1))
    elif char == "-":
      total -= math.pow(5,abs(index)-1)
    else:
      total += int(char)*(math.pow(5,abs(index)-1))
  return total

fileTotal = 0
for item in fileList:
  fileTotal+=SNAFUtoDecimal(item)
print(DecimaltoSNAFU(fileTotal))