for (let y=0; y<10;y++){
  document.getElementById("grid").innerHTML+="<div id="+String(y)+"></div>";
for (let x=0; x<10;x++){
  document.getElementById(y).innerHTML+="<div class = 'box' id='"+String(x)+"x"+String(y)+"'></div>";
}}
/*
8624818384
3725473343
6618341827
4573826616
8357322142
6846358317
7286886112
8138685117
6161124267
3848415383
*/
var tally=0;
var initial=[8,6,2,4,8,1,8,3,8,4,3,7,2,5,4,7,3,3,4,3,6,6,1,8,3,4,1,8,2,7,4,5,7,3,8,2,6,6,1,6,8,3,5,7,3,2,2,1,4,2,6,8,4,6,3,5,8,3,1,7,7,2,8,6,8,8,6,1,1,2,8,1,3,8,6,8,5,1,1,7,6,1,6,1,1,2,4,2,6,7,3,8,4,8,4,1,5,3,8,3];
var counter=0;
var score=0;
refreshScore();
for (let setupy=0; setupy<10; setupy++){
  for (let setupx=0; setupx<10; setupx++){
    document.getElementById(String(setupx)+"x"+String(setupy)).innerHTML=(initial[counter]);
    counter+=1
  }
}
function refreshScore(){
  document.getElementById("score").innerHTML="Amount: "+String(score);
}
function increase(){
  tally=0;
  score++;
  var outlaw=[]
for (let xx=0; xx<10; xx++){
  for (let yy=0; yy<10; yy++){      
    var oldVal = document.getElementById(String(xx)+"x"+String(yy)).innerHTML;
   document.getElementById(String(xx)+"x"+String(yy)).innerHTML=parseInt(oldVal)+1;
    }
  }
  scanner(outlaw);
}

document.getElementById("button").addEventListener("click",increase);

function increaseIndiv(id){
  var ogVal = document.getElementById(id).innerHTML;
  document.getElementById(id).innerHTML=parseInt(ogVal)+1;
  }
document.getElementById("button").addEventListener("click",increase);
function scanner(outlaw){
for (let xx=0; xx<10; xx++){
  for (let yy=0; yy<10; yy++){
    var coords = String(xx)+"x"+String(yy);
    var oldVal2=document.getElementById(coords).innerHTML;
    if (outlaw.indexOf(coords)==-1){
    if (parseInt(oldVal2)>9){
      if(xx<9){
      increaseIndiv(String(xx+1)+"x"+String(yy));
      if(yy>0){
      increaseIndiv(String(xx+1)+"x"+String(yy-1));}
      if(yy<9){
      increaseIndiv(String(xx+1)+"x"+String(yy+1));}
      }
      if(yy<9){
      increaseIndiv(String(xx)+"x"+String(yy+1));}
      if(yy>0){
      increaseIndiv(String(xx)+"x"+String(yy-1));}
      if(xx>0){
      increaseIndiv(String(xx-1)+"x"+String(yy));}
      if(xx>0&&yy>0){
      increaseIndiv(String(xx-1)+"x"+String(yy-1));}
      if(xx>0&&yy<9){
      increaseIndiv(String(xx-1)+"x"+String(yy+1));}
      outlaw.push(coords);
      scanner(outlaw)
    }}
  }
}
scanner2();
}
function scanner2(){
  for (let xx=0; xx<10; xx++){
  for (let yy=0; yy<10; yy++){
    var oldVal3 = document.getElementById(String(xx)+'x'+String(yy)).innerHTML;
    if (parseInt(oldVal3)>9){
      document.getElementById(String(xx)+"x"+String(yy)).innerHTML=0;
    }
  }}
refreshScore();
}